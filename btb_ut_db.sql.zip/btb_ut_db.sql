-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 14, 2009 at 05:29 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `btb_ut_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `active_guests`
--

CREATE TABLE IF NOT EXISTS `active_guests` (
  `ip` varchar(15) NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `active_guests`
--


-- --------------------------------------------------------

--
-- Table structure for table `active_users`
--

CREATE TABLE IF NOT EXISTS `active_users` (
  `username` varchar(30) NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `active_users`
--

INSERT INTO `active_users` (`username`, `timestamp`) VALUES
('http://unique-technologies.net', 1252855967);

-- --------------------------------------------------------

--
-- Table structure for table `banned_users`
--

CREATE TABLE IF NOT EXISTS `banned_users` (
  `username` varchar(30) NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banned_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `mmsmessages`
--

CREATE TABLE IF NOT EXISTS `mmsmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `message` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `approved` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

--
-- Dumping data for table `mmsmessages`
--

INSERT INTO `mmsmessages` (`id`, `username`, `message`, `approved`) VALUES
(50, 'http://unique-technologies.net', '<p><b>5345453343453455345</b></p>', 0),
(48, 'asdasd', '<p><b>fghdfg hdfgh', 0),
(49, 'asdasd', '<p><b>5345453343453455345</b></p>', 0),
(47, 'http://unique-technologies.net', '<p><b>fghdfg hdfgh', 0),
(51, 'http://unique-technologies.net', '<p><b>dfgh dfh dfh dh', 0),
(56, 'http://unique-technologies.net', '<p><b>xfg dfg dfg dg dg dg</b></p>', 0);

-- --------------------------------------------------------

--
-- Table structure for table `smsmessages`
--

CREATE TABLE IF NOT EXISTS `smsmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `duration` int(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=85 ;

--
-- Dumping data for table `smsmessages`
--

INSERT INTO `smsmessages` (`id`, `username`, `message`, `duration`) VALUES
(50, 'admin', '<b> Click here to enter an sms message </b>', 966),
(79, 'http://unique-technologies.net', 'sgdfgsdfg', 22),
(73, 'admin', 'fgdhfgh', -567),
(78, 'asdasd', 'sgdfgsdfg', -22),
(77, 'http://unique-technologies.net', 'dfg sdfg ', 44),
(80, 'asdasd', '<b> Click here to send a SMS ! </b>11111111111111111111111111111', -11),
(81, 'asdasd', '<b> Click here to send a SMS ! </b>11111111111111111111111111111', -11),
(83, 'http://unique-technologies.net', '<b> Click here to send a SMS ! </b>22222222222222222222222222', 55);

-- --------------------------------------------------------

--
-- Table structure for table `tracked_data`
--

CREATE TABLE IF NOT EXISTS `tracked_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) NOT NULL,
  `date` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tracked_data`
--

INSERT INTO `tracked_data` (`id`, `ip`, `date`, `country`) VALUES
(1, '111.111.111.111', 'dfasdf', 'sdfasdf'),
(2, '111.111.111.111', 'dfasdf', 'sdfasdf'),
(3, '127.0.0.1', '10-08', ''),
(4, '127.0.0.1', '10-08', ''),
(5, '76786', '12-08', 'gvkgh');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(30) NOT NULL,
  `password` varchar(32) DEFAULT NULL,
  `userid` varchar(32) DEFAULT NULL,
  `userlevel` tinyint(1) unsigned NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  `closed` int(255) NOT NULL,
  `online` int(255) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `userid`, `userlevel`, `email`, `timestamp`, `closed`, `online`) VALUES
('admin', '5f4dcc3b5aa765d61d8327deb882cf99', '404ae3a07bdddac625fde7bfed2c81e9', 9, 'fazall@unique-technologies.net', 1252849725, 0, 0),
('http://unique-technologies.net', '5f4dcc3b5aa765d61d8327deb882cf99', '88c591646e8d41112bc0e27185795c30', 0, 'asd@asd.asd', 1252855967, 0, 0),
('asdasd', '96e79218965eb72c92a549dd5a330112', '11582c2dc224064a0281b2a919693b11', 1, '111@111.sdf', 1252595479, 1, 1);
